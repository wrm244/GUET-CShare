See doc/index.html or doc/hacking.pdf for information about GeekOS
