#include "../libc/fmtout.h"
