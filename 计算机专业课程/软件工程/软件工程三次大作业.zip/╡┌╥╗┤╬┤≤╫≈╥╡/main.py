
import random
from collections import deque

class VassalState:
    def __init__(self, name):
        self.name = name
        self.signal_time = float('inf')
        self.beacon_time = random.randint(1, 5)

class SquareGrid:
    def __init__(self, n, blocked_edges):
        self.n = n
        self.grid = self.generate_square_grid()
        self.boundary = self.find_boundary()
        self.paths = {}
        self.blocked_edges = blocked_edges

    def generate_square_grid(self):
        grid = []
        for i in range(self.n):
            row = []
            for j in range(self.n):
                row.append(VassalState(chr(65 + i * self.n + j)))
            grid.append(row)
        return grid

    def find_boundary(self):
        boundary = set()
        for i in range(self.n):
            boundary.add(self.grid[i][0])
            boundary.add(self.grid[i][self.n-1])
            boundary.add(self.grid[0][i])
            boundary.add(self.grid[self.n-1][i])
        return boundary

    def find_neighbors(self, node):
        neighbors = []
        for i in range(self.n):
            for j in range(self.n):
                if self.grid[i][j] == node:
                    if i > 0 and (node.name, self.grid[i-1][j].name) not in self.blocked_edges and (self.grid[i-1][j].name, node.name) not in self.blocked_edges:
                        neighbors.append(self.grid[i-1][j])
                    if i < self.n-1 and (node.name, self.grid[i+1][j].name) not in self.blocked_edges and (self.grid[i+1][j].name, node.name) not in self.blocked_edges:
                        neighbors.append(self.grid[i+1][j])
                    if j > 0 and (node.name, self.grid[i][j-1].name) not in self.blocked_edges and (self.grid[i][j-1].name, node.name) not in self.blocked_edges:
                        neighbors.append(self.grid[i][j-1])
                    if j < self.n-1 and (node.name, self.grid[i][j+1].name) not in self.blocked_edges and (self.grid[i][j+1].name, node.name) not in self.blocked_edges:
                        neighbors.append(self.grid[i][j+1])
                    return neighbors

    def simulate_signal(self):
        visited = set()
        emperor = self.grid[self.n//2][self.n//2]
        emperor.signal_time = 0
        queue = deque([(emperor, 0, [])])
        while queue:
            node, time, path = queue.popleft()
            if node not in visited:
                visited.add(node)
                print(f"在第{time}个时间单位，{node.name}接收到信号并在第{time + node.beacon_time}个时间单位点燃了烽火。")
                node.signal_time = time + node.beacon_time
                path.append(node.name)
                self.paths[node] = path.copy()
                neighbors = self.find_neighbors(node)
                for neighbor in neighbors:
                    if neighbor not in visited:
                        queue.append((neighbor, time + node.beacon_time, path))

n = random.randint(3, 6)
blocked_edges = {('A', 'B'), ('C', 'D')}
square_grid = SquareGrid(n, blocked_edges)

print("正方形网格:")
for row in square_grid.grid:
    print(" ".join([vassal_state.name for vassal_state in row]))

print("\n边界节点:", [vassal_state.name for vassal_state in square_grid.boundary])

square_grid.simulate_signal()

print("\n边界节点的信号时间和路径:")
for vassal_state in square_grid.boundary:
    print(f"{vassal_state.name}: {vassal_state.signal_time}, {'->'.join(square_grid.paths[vassal_state])}")

min_time = float('inf')
min_path = []
for vassal_state in square_grid.boundary:
    if vassal_state.signal_time < min_time:
        min_time = vassal_state.signal_time
        min_path = square_grid.paths[vassal_state]

print(f"\n从天子到边界节点的最短路径是{'->'.join(min_path)}，时间为{min_time}个时间单位。")
