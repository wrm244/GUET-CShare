
# 定义大象类
class Elephant:
    # 初始化大象的重量
    def __init__(self, weight):
        self.weight = weight

    # 返回大象的重量
    def get_weight(self):
        return self.weight

# 定义船类
class Boat:
    # 初始化船的大小和容量
    def __init__(self, size, capacity):
        self.size = size
        self.capacity = capacity
        self.load = 0 # 船上的载重
        self.water_level = 0 # 船下的水位

    # 返回船的大小
    def get_size(self):
        return self.size

    # 返回船的容量
    def get_capacity(self):
        return self.capacity

    # 返回船上的载重
    def get_load(self):
        return self.load

    # 返回船下的水位
    def get_water_level(self):
        return self.water_level

    # 让大象进入船中，增加载重，增加水位
    def enter_elephant(self, elephant):
        if self.load + elephant.get_weight() <= self.capacity:
            self.load += elephant.get_weight()
            self.water_level += elephant.get_weight() / self.size
            print("大象进入船中，船上的载重为{}，船下的水位为{}".format(self.load, self.water_level))
        else:
            print("船已经满了，不能再进入大象")

    # 让大象离开船中，减少载重，减少水位
    def exit_elephant(self, elephant):
        if self.load >= elephant.get_weight():
            self.load -= elephant.get_weight()
            self.water_level -= elephant.get_weight() / self.size
            print("大象离开船中，船上的载重为{}，船下的水位为{}".format(self.load, self.water_level))
        else:
            print("船上没有大象，不能让大象离开")

# 定义水池类
class Pool:
    # 初始化水池的大小和初始水位
    def __init__(self, size, initial_water_level):
        self.size = size
        self.initial_water_level = initial_water_level

    # 返回水池的大小
    def get_size(self):
        return self.size

    # 返回水池的初始水位
    def get_initial_water_level(self):
        return self.initial_water_level

# 定义石头类
class Stone:
    # 初始化石头的重量
    def __init__(self, weight):
        self.weight = weight

    # 返回石头的重量
    def get_weight(self):
        return self.weight

