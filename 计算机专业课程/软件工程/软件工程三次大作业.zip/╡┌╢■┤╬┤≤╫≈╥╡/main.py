
# 导入tkinter模块和其他相关模块
import tkinter as tk
import tkinter.ttk as ttk
import tkinter.messagebox as messagebox

# 导入之前定义的类
from cao_chong import Elephant, Boat, Pool, Stone

# 创建一个Tk对象，它是一个顶层窗口，可以容纳其他组件
window = tk.Tk()

# 创建一个标签，显示"曹冲称象模拟游戏"
label_title = tk.Label(window, text="曹冲称象模拟游戏", font=("Arial", 20))
# 使用grid布局管理器，将标签放在第0行第0列，跨越2列
label_title.grid(row=0, column=0, columnspan=2)

# 创建一个标签，显示"请输入大象的重量（单位：千克）："
label_elephant = tk.Label(window, text="请输入大象的重量（单位：千克）：")
# 使用grid布局管理器，将标签放在第1行第0列
label_elephant.grid(row=1, column=0)

# 创建一个输入框，用来输入大象的重量
entry_elephant = tk.Entry(window)
# 使用grid布局管理器，将输入框放在第1行第1列
entry_elephant.grid(row=1, column=1)

# 创建一个标签，显示"请输入船的大小（单位：立方米）："
label_boat = tk.Label(window, text="请输入船的大小（单位：立方米）：")
# 使用grid布局管理器，将标签放在第2行第0列
label_boat.grid(row=2, column=0)

# 创建一个输入框，用来输入船的大小
entry_boat = tk.Entry(window)
# 使用grid布局管理器，将输入框放在第2行第1列
entry_boat.grid(row=2, column=1)

# 创建一个标签，显示"请输入水池的大小（单位：立方米）："
label_pool = tk.Label(window, text="请输入水池的大小（单位：立方米）：")
# 使用grid布局管理器，将标签放在第3行第0列
label_pool.grid(row=3, column=0)

# 创建一个输入框，用来输入水池的大小
entry_pool = tk.Entry(window)
# 使用grid布局管理器，将输入框放在第3行第1列
entry_pool.grid(row=3, column=1)

# 创建一个标签，显示"请输入水池的初始水位（单位：米）："
label_water = tk.Label(window, text="请输入水池的初始水位（单位：米）：")
# 使用grid布局管理器，将标签放在第4行第0列
label_water.grid(row=4, column=0)

# 创建一个输入框，用来输入水池的初始水位
entry_water = tk.Entry(window)
# 使用grid布局管理器，将输入框放在第4行第1列
entry_water.grid(row=4, column=1)

# 创建一个列表框，用来显示石头的重量列表
listbox_stone = tk.Listbox(window)
# 使用grid布局管理器，将列表框放在第5行第0列，跨越2列
listbox_stone.grid(row=5, column=0, columnspan=2)

# 定义一个事件处理函数，用来响应添加按钮的点击事件
def button_add_click():
    # 获取石头重量输入框中的内容，并转换为整数
    stone_weight = int(entry_stone.get())
    # 将石头重量添加到列表框中
    listbox_stone.insert(tk.END, stone_weight)
    # 清空石头重量输入框中的内容
    entry_stone.delete(0, tk.END)

# 定义一个事件处理函数，用来响应删除按钮的点击事件
def button_delete_click():
    # 获取列表框中选中的项目索引
    index = listbox_stone.curselection()
    # 如果有选中的项目，则删除之
    if index:
        listbox_stone.delete(index)

# 定义一个事件处理函数，用来响应开始按钮的点击事件
def button_start_click():
    # 获取各个输入框中的内容，并转换为相应类型
    elephant_weight = int(entry_elephant.get())
    boat_size = int(entry_boat.get())
    boat_capacity = boat_size * 1000 # 假设船的容量等于船的大小乘以1000千克/立方米
    pool_size = int(entry_pool.get())
    pool_initial_water_level = int(entry_water.get())
    
    # 创建相应的对象，并调用之前定义的类中的方法
    elephant = Elephant(elephant_weight)
    boat = Boat(boat_size, boat_capacity)
    pool = Pool(pool_size, pool_initial_water_level)
    
    # 模拟大象进入船中，记录水位上升
    boat.enter_elephant(elephant)

    # 模拟大象离开船中，石块进入船中，直到水位恢复到原来位置
    stone_list = [] # 存储石块对象的列表
    stone_weight_sum = 0 # 存储石块总重量
    
    # 遍历列表框中的所有项目，并创建相应的石头对象
    for item in listbox_stone.get(0, tk.END):
        stone_weight = int(item) # 获取石头重量，并转换为整数
        stone = Stone(stone_weight) # 创建石头对象，并添加到列表中
        stone_list.append(stone)
        stone_weight_sum += stone.get_weight() # 累加石块总重量
        
        # 让石头进入船中，增加载重，增加水位，并判断是否达到目标水位
        boat.enter_elephant(stone)
        if boat.get_water_level() <= pool.get_initial_water_level():
            break
    
    # 让大象离开船中，减少载重，减少水位    
    boat.exit_elephant(elephant)

    # 计算石块总重量，并显示结果
    messagebox.showinfo("结果", "石块总重量为{}千克\n根据曹冲称象原理，可以推断出大象的重量也为{}千克".format(stone_weight_sum, stone_weight_sum))

# 创建一个标签，显示"请输入石头的重量（单位：千克）："
label_stone = tk.Label(window, text="请输入石头的重量（单位：千克）：")
# 使用grid布局管理器，将标签放在第6行第0列
label_stone.grid(row=6, column=0)

# 创建一个输入框，用来输入石头的重量
entry_stone = tk.Entry(window)
# 使用grid布局管理器，将输入框放在第6行第1列
entry_stone.grid(row=6, column=1)

# 创建一个按钮，显示"添加"
button_add = tk.Button(window, text="添加", command=button_add_click)
# 使用grid布局管理器，将按钮放在第7行第0列
button_add.grid(row=7, column=0)

# 创建另一个按钮，显示"删除"
button_delete = tk.Button(window, text="删除", command=button_delete_click)
# 使用grid布局管理器，将按钮放在第7行第1列
button_delete.grid(row=7, column=1)

# 创建另一个按钮，显示"开始模拟"
button_start = tk.Button(window, text="开始模拟", command=button_start_click)
# 使用grid布局管理器，将按钮放在第8行第0列，跨越2列
button_start.grid(row=8, column=0, columnspan=2)

# 调用Tk对象的mainloop方法，进入事件循环
window.mainloop()
